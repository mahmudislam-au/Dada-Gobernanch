// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title HealthcareDataGovernance
 * @notice A blockchain-based patient consent management system for healthcare data governance.
 * @dev Enables patients to control who can access their health records, with immutable audit trails.
 *
 * Problem Solved:
 * - Patient health data is siloed across hospitals, GPs, pathology labs, and specialists.
 * - Consent is tracked inconsistently (paper forms, fragmented digital systems).
 * - Data breaches are frequent due to weak access controls.
 * - Patients lack transparency over who accessed their records and when.
 *
 * How This Contract Solves It:
 * - Patients register and become the sole owners of their consent permissions.
 * - Providers are registered by a trusted admin (e.g., health department).
 * - Patients grant time-bound, category-specific access to providers.
 * - Every data access is logged on-chain, creating an immutable audit trail.
 * - Patients can revoke access at any time.
 */
contract HealthcareDataGovernance {

    // ──────────────────────────────────────────────
    // Enums
    // ──────────────────────────────────────────────

    /// @notice Categories of health data a patient can share
    enum DataCategory {
        GeneralHealth,      // 0 - GP visit summaries, vitals
        Pathology,          // 1 - Blood tests, lab results
        Radiology,          // 2 - X-rays, MRIs, CT scans
        Medication,         // 3 - Prescriptions, pharmacy records
        MentalHealth,       // 4 - Psychology/psychiatry notes
        Surgical            // 5 - Surgical history and records
    }

    // ──────────────────────────────────────────────
    // Structs
    // ──────────────────────────────────────────────

    /// @notice Represents a registered patient
    struct Patient {
        string name;
        bool isRegistered;
        uint256 registeredAt;
    }

    /// @notice Represents a registered healthcare provider
    struct Provider {
        string name;
        string licenceNumber;
        bool isRegistered;
        uint256 registeredAt;
    }

    /// @notice A consent permission granted by a patient to a provider
    struct ConsentRecord {
        address patient;
        address provider;
        DataCategory category;
        uint256 grantedAt;
        uint256 expiresAt;
        bool isActive;
    }

    /// @notice An immutable log entry when a provider accesses patient data
    struct AccessLog {
        address provider;
        address patient;
        DataCategory category;
        uint256 accessedAt;
        string purposeNote;
    }

    // ──────────────────────────────────────────────
    // State Variables
    // ──────────────────────────────────────────────

    address public admin;

    mapping(address => Patient) public patients;
    mapping(address => Provider) public providers;

    // patient => provider => category => ConsentRecord
    mapping(address => mapping(address => mapping(DataCategory => ConsentRecord))) public consents;

    // patient => list of access logs
    mapping(address => AccessLog[]) public accessLogs;

    // Counters for analytics
    uint256 public totalPatients;
    uint256 public totalProviders;
    uint256 public totalConsentsGranted;
    uint256 public totalAccessEvents;

    // ──────────────────────────────────────────────
    // Events
    // ──────────────────────────────────────────────

    event PatientRegistered(address indexed patient, string name, uint256 timestamp);
    event ProviderRegistered(address indexed provider, string name, string licenceNumber, uint256 timestamp);
    event ConsentGranted(address indexed patient, address indexed provider, DataCategory category, uint256 expiresAt);
    event ConsentRevoked(address indexed patient, address indexed provider, DataCategory category, uint256 timestamp);
    event DataAccessed(address indexed provider, address indexed patient, DataCategory category, uint256 timestamp, string purposeNote);
    event EmergencyAccessUsed(address indexed provider, address indexed patient, uint256 timestamp, string reason);

    // ──────────────────────────────────────────────
    // Modifiers
    // ──────────────────────────────────────────────

    modifier onlyAdmin() {
        require(msg.sender == admin, "Only admin can perform this action");
        _;
    }

    modifier onlyRegisteredPatient() {
        require(patients[msg.sender].isRegistered, "Caller is not a registered patient");
        _;
    }

    modifier onlyRegisteredProvider() {
        require(providers[msg.sender].isRegistered, "Caller is not a registered provider");
        _;
    }

    // ──────────────────────────────────────────────
    // Constructor
    // ──────────────────────────────────────────────

    /// @notice Deploys the contract and sets the deployer as admin
    constructor() {
        admin = msg.sender;
    }

    // ──────────────────────────────────────────────
    // Registration Functions
    // ──────────────────────────────────────────────

    /// @notice Register a new patient (self-registration)
    /// @param _name The patient's full name
    function registerPatient(string calldata _name) external {
        require(!patients[msg.sender].isRegistered, "Patient already registered");
        require(bytes(_name).length > 0, "Name cannot be empty");

        patients[msg.sender] = Patient({
            name: _name,
            isRegistered: true,
            registeredAt: block.timestamp
        });

        totalPatients++;
        emit PatientRegistered(msg.sender, _name, block.timestamp);
    }

    /// @notice Register a healthcare provider (admin only, ensures legitimacy)
    /// @param _providerAddress The wallet address of the provider
    /// @param _name The provider's name or organisation
    /// @param _licenceNumber The provider's medical licence number
    function registerProvider(
        address _providerAddress,
        string calldata _name,
        string calldata _licenceNumber
    ) external onlyAdmin {
        require(!providers[_providerAddress].isRegistered, "Provider already registered");
        require(bytes(_name).length > 0, "Name cannot be empty");
        require(bytes(_licenceNumber).length > 0, "Licence number cannot be empty");

        providers[_providerAddress] = Provider({
            name: _name,
            licenceNumber: _licenceNumber,
            isRegistered: true,
            registeredAt: block.timestamp
        });

        totalProviders++;
        emit ProviderRegistered(_providerAddress, _name, _licenceNumber, block.timestamp);
    }

    // ──────────────────────────────────────────────
    // Consent Management
    // ──────────────────────────────────────────────

    /// @notice Patient grants a provider time-bound access to a specific data category
    /// @param _provider The address of the healthcare provider
    /// @param _category The category of health data to share
    /// @param _durationInDays How many days the consent is valid for
    function grantConsent(
        address _provider,
        DataCategory _category,
        uint256 _durationInDays
    ) external onlyRegisteredPatient {
        require(providers[_provider].isRegistered, "Provider is not registered");
        require(_durationInDays > 0 && _durationInDays <= 365, "Duration must be 1-365 days");

        uint256 expiryTime = block.timestamp + (_durationInDays * 1 days);

        consents[msg.sender][_provider][_category] = ConsentRecord({
            patient: msg.sender,
            provider: _provider,
            category: _category,
            grantedAt: block.timestamp,
            expiresAt: expiryTime,
            isActive: true
        });

        totalConsentsGranted++;
        emit ConsentGranted(msg.sender, _provider, _category, expiryTime);
    }

    /// @notice Patient revokes a provider's access to a specific data category
    /// @param _provider The address of the healthcare provider
    /// @param _category The category of health data to revoke
    function revokeConsent(
        address _provider,
        DataCategory _category
    ) external onlyRegisteredPatient {
        ConsentRecord storage consent = consents[msg.sender][_provider][_category];
        require(consent.isActive, "No active consent to revoke");

        consent.isActive = false;
        emit ConsentRevoked(msg.sender, _provider, _category, block.timestamp);
    }

    // ──────────────────────────────────────────────
    // Data Access
    // ──────────────────────────────────────────────

    /// @notice Provider accesses patient data (checks consent, logs access)
    /// @param _patient The address of the patient whose data is being accessed
    /// @param _category The data category being accessed
    /// @param _purposeNote A brief note explaining the clinical purpose
    function accessPatientData(
        address _patient,
        DataCategory _category,
        string calldata _purposeNote
    ) external onlyRegisteredProvider {
        require(patients[_patient].isRegistered, "Patient is not registered");

        ConsentRecord storage consent = consents[_patient][msg.sender][_category];
        require(consent.isActive, "No active consent for this data category");
        require(block.timestamp <= consent.expiresAt, "Consent has expired");

        // Log the access on-chain
        accessLogs[_patient].push(AccessLog({
            provider: msg.sender,
            patient: _patient,
            category: _category,
            accessedAt: block.timestamp,
            purposeNote: _purposeNote
        }));

        totalAccessEvents++;
        emit DataAccessed(msg.sender, _patient, _category, block.timestamp, _purposeNote);
    }

    /// @notice Emergency access override — bypasses consent but is permanently logged
    /// @param _patient The patient whose data is being accessed in emergency
    /// @param _category The data category needed
    /// @param _reason The clinical emergency reason
    function emergencyAccess(
        address _patient,
        DataCategory _category,
        string calldata _reason
    ) external onlyRegisteredProvider {
        require(patients[_patient].isRegistered, "Patient is not registered");
        require(bytes(_reason).length > 0, "Emergency reason is required");

        // Log emergency access — no consent check, but permanently recorded
        accessLogs[_patient].push(AccessLog({
            provider: msg.sender,
            patient: _patient,
            category: _category,
            accessedAt: block.timestamp,
            purposeNote: string(abi.encodePacked("EMERGENCY: ", _reason))
        }));

        totalAccessEvents++;
        emit EmergencyAccessUsed(msg.sender, _patient, block.timestamp, _reason);
    }

    // ──────────────────────────────────────────────
    // View Functions
    // ──────────────────────────────────────────────

    /// @notice Check if a provider currently has valid consent for a patient's data category
    /// @return hasConsent Whether active, non-expired consent exists
    function checkConsent(
        address _patient,
        address _provider,
        DataCategory _category
    ) external view returns (bool hasConsent) {
        ConsentRecord storage consent = consents[_patient][_provider][_category];
        return consent.isActive && block.timestamp <= consent.expiresAt;
    }

    /// @notice Get the number of access log entries for a patient
    /// @param _patient The patient's address
    /// @return count The total number of access events
    function getAccessLogCount(address _patient) external view returns (uint256 count) {
        return accessLogs[_patient].length;
    }

    /// @notice Retrieve a specific access log entry for a patient
    /// @param _patient The patient's address
    /// @param _index The index of the log entry
    function getAccessLog(
        address _patient,
        uint256 _index
    ) external view returns (
        address provider,
        DataCategory category,
        uint256 accessedAt,
        string memory purposeNote
    ) {
        require(_index < accessLogs[_patient].length, "Index out of bounds");
        AccessLog storage log = accessLogs[_patient][_index];
        return (log.provider, log.category, log.accessedAt, log.purposeNote);
    }

    /// @notice Get consent details for a specific patient-provider-category combination
    function getConsentDetails(
        address _patient,
        address _provider,
        DataCategory _category
    ) external view returns (
        uint256 grantedAt,
        uint256 expiresAt,
        bool isActive
    ) {
        ConsentRecord storage consent = consents[_patient][_provider][_category];
        return (consent.grantedAt, consent.expiresAt, consent.isActive);
    }
}
