# 🏥 Blockchain-Based Healthcare Data Governance

> A Solidity smart contract system for patient-controlled health data consent management, built as a case study for BUSA3007 — Data Governance with Blockchain.

## 📋 Table of Contents
- [Problem Statement](#problem-statement)
- [Our Solution](#our-solution)
- [Architecture](#architecture)
- [Smart Contract Design](#smart-contract-design)
- [Tech Stack](#tech-stack)
- [Setup & Installation](#setup--installation)
- [Testing](#testing)
- [Usage Examples](#usage-examples)
- [Team](#team)

---

## Problem Statement

Healthcare data governance in Australia faces critical challenges:

1. **Data Silos** — Patient records are fragmented across hospitals, GPs, pathology labs, and specialists with no unified access layer.
2. **Inconsistent Consent Tracking** — Consent is managed through paper forms and disconnected digital systems, making it difficult to verify who has permission to access what.
3. **Frequent Data Breaches** — Centralised databases are honeypots for attackers. The Australian healthcare sector reported 104 data breaches in H2 2023 alone (OAIC, 2024).
4. **Lack of Patient Control** — Patients cannot easily see who accessed their records, when, and why. Transparency is minimal.
5. **My Health Record Trust Issues** — Australia's national digital health record system faced significant public opt-out rates due to privacy and trust concerns.

## Our Solution

We developed a **permissioned blockchain-based consent management system** using Ethereum smart contracts (Solidity) that:

- **Gives patients ownership** of their consent decisions — they grant and revoke access directly on-chain.
- **Enforces time-bound, category-specific consent** — a patient can share pathology results with a specialist for 30 days without exposing mental health notes.
- **Creates an immutable audit trail** — every data access event is permanently logged, giving patients full transparency.
- **Supports emergency access** — providers can access data in emergencies, but the override is permanently recorded and flagged.
- **Uses role-based access control** — only verified providers (registered by a trusted admin) can request access.

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                    Frontend (React)                  │
│         Patient Dashboard  |  Provider Portal       │
└──────────────────────┬──────────────────────────────┘
                       │ ethers.js / Web3
┌──────────────────────▼──────────────────────────────┐
│              Ethereum Blockchain (Testnet)           │
│  ┌────────────────────────────────────────────────┐  │
│  │      HealthcareDataGovernance.sol              │  │
│  │                                                │  │
│  │  - registerPatient()                           │  │
│  │  - registerProvider()      [Admin only]        │  │
│  │  - grantConsent()          [Patient only]      │  │
│  │  - revokeConsent()         [Patient only]      │  │
│  │  - accessPatientData()     [Provider only]     │  │
│  │  - emergencyAccess()       [Provider only]     │  │
│  │  - checkConsent()          [View]              │  │
│  │  - getAccessLog()          [View]              │  │
│  └────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────┘
```

## Smart Contract Design

### Data Categories
Patients can grant access at a granular level across six categories:

| Enum Value | Category       | Description                          |
|------------|----------------|--------------------------------------|
| 0          | GeneralHealth  | GP visit summaries, vitals           |
| 1          | Pathology      | Blood tests, lab results             |
| 2          | Radiology      | X-rays, MRIs, CT scans               |
| 3          | Medication     | Prescriptions, pharmacy records      |
| 4          | MentalHealth   | Psychology/psychiatry notes          |
| 5          | Surgical       | Surgical history and records         |

### Key Design Decisions

1. **Patient self-registration, admin-only provider registration** — prevents impersonation of healthcare providers.
2. **Time-bound consent (1–365 days)** — prevents stale permissions lingering indefinitely.
3. **Emergency access with permanent logging** — balances clinical necessity with accountability.
4. **On-chain audit trail** — access logs are immutable and cannot be tampered with by any party.

### Access Control (Modifiers)
- `onlyAdmin` — Contract deployer (e.g., health department)
- `onlyRegisteredPatient` — Verified patients only
- `onlyRegisteredProvider` — Admin-approved providers only

## Tech Stack

| Component        | Technology               |
|-----------------|--------------------------|
| Smart Contract   | Solidity ^0.8.19         |
| Framework        | Hardhat                  |
| Testing          | Chai + Ethers.js         |
| Network          | Ethereum Sepolia Testnet |
| Frontend (optional) | React + ethers.js    |

## Setup & Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/healthcare-data-governance-blockchain.git
cd healthcare-data-governance-blockchain

# Install dependencies
npm install

# Compile the contract
npx hardhat compile

# Run tests
npx hardhat test

# Deploy to local Hardhat network
npx hardhat run scripts/deploy.js

# Deploy to Sepolia testnet (requires .env with SEPOLIA_RPC_URL and PRIVATE_KEY)
npx hardhat run scripts/deploy.js --network sepolia
```

## Testing

All tests are located in `test/HealthcareDataGovernance.test.js` and cover:

- ✅ Patient registration (success + duplicate rejection)
- ✅ Provider registration (admin-only enforcement)
- ✅ Consent granting and revocation
- ✅ Data access with valid consent
- ✅ Data access rejection without consent
- ✅ Emergency access logging
- ✅ Counter/analytics tracking

Run with:
```bash
npx hardhat test
```

## Usage Examples

### 1. Register a Patient
```solidity
contract.registerPatient("Alice Smith");
```

### 2. Register a Provider (Admin)
```solidity
contract.registerProvider(0xProviderAddress, "Sydney Hospital", "MED-12345");
```

### 3. Grant Consent (Patient)
```solidity
// Grant Sydney Hospital access to Pathology data for 30 days
contract.grantConsent(0xProviderAddress, DataCategory.Pathology, 30);
```

### 4. Access Patient Data (Provider)
```solidity
contract.accessPatientData(0xPatientAddress, DataCategory.Pathology, "Reviewing blood test results");
```

### 5. Revoke Consent (Patient)
```solidity
contract.revokeConsent(0xProviderAddress, DataCategory.Pathology);
```

### 6. Emergency Access (Provider)
```solidity
contract.emergencyAccess(0xPatientAddress, DataCategory.GeneralHealth, "Patient unconscious in ED");
```

## Team

| Name   | Student ID | Role                           |
|--------|------------|--------------------------------|
| Krish  | c_______   | Smart Contract & Report Lead   |
| Member 2 | c_______  | Research & Presentation       |
| Member 3 | c_______  | Testing & Frontend            |

---

**Course:** BUSA3007 — Data Governance with Blockchain  
**University of Newcastle, Australia**  
**Semester 1, 2026**
