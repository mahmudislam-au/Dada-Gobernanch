const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("HealthcareDataGovernance", function () {
  let contract, admin, patient1, provider1, provider2;

  beforeEach(async function () {
    [admin, patient1, provider1, provider2] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory("HealthcareDataGovernance");
    contract = await Factory.deploy();
    await contract.waitForDeployment();
  });

  describe("Registration", function () {
    it("should register a patient", async function () {
      await contract.connect(patient1).registerPatient("Alice Smith");
      const patient = await contract.patients(patient1.address);
      expect(patient.isRegistered).to.be.true;
      expect(patient.name).to.equal("Alice Smith");
    });

    it("should not allow duplicate patient registration", async function () {
      await contract.connect(patient1).registerPatient("Alice Smith");
      await expect(
        contract.connect(patient1).registerPatient("Alice Smith")
      ).to.be.revertedWith("Patient already registered");
    });

    it("should register a provider (admin only)", async function () {
      await contract.registerProvider(provider1.address, "Sydney Hospital", "MED-12345");
      const prov = await contract.providers(provider1.address);
      expect(prov.isRegistered).to.be.true;
    });

    it("should reject provider registration from non-admin", async function () {
      await expect(
        contract.connect(patient1).registerProvider(provider1.address, "Hospital", "LIC-1")
      ).to.be.revertedWith("Only admin can perform this action");
    });
  });

  describe("Consent Management", function () {
    beforeEach(async function () {
      await contract.connect(patient1).registerPatient("Alice Smith");
      await contract.registerProvider(provider1.address, "Sydney Hospital", "MED-12345");
    });

    it("should grant consent", async function () {
      await contract.connect(patient1).grantConsent(provider1.address, 0, 30); // GeneralHealth, 30 days
      const hasConsent = await contract.checkConsent(patient1.address, provider1.address, 0);
      expect(hasConsent).to.be.true;
    });

    it("should revoke consent", async function () {
      await contract.connect(patient1).grantConsent(provider1.address, 0, 30);
      await contract.connect(patient1).revokeConsent(provider1.address, 0);
      const hasConsent = await contract.checkConsent(patient1.address, provider1.address, 0);
      expect(hasConsent).to.be.false;
    });

    it("should reject consent grant to unregistered provider", async function () {
      await expect(
        contract.connect(patient1).grantConsent(provider2.address, 0, 30)
      ).to.be.revertedWith("Provider is not registered");
    });
  });

  describe("Data Access", function () {
    beforeEach(async function () {
      await contract.connect(patient1).registerPatient("Alice Smith");
      await contract.registerProvider(provider1.address, "Sydney Hospital", "MED-12345");
      await contract.connect(patient1).grantConsent(provider1.address, 0, 30);
    });

    it("should allow access with valid consent", async function () {
      await contract.connect(provider1).accessPatientData(patient1.address, 0, "Routine check-up");
      const count = await contract.getAccessLogCount(patient1.address);
      expect(count).to.equal(1);
    });

    it("should reject access without consent", async function () {
      await expect(
        contract.connect(provider1).accessPatientData(patient1.address, 1, "Lab review") // Pathology - no consent
      ).to.be.revertedWith("No active consent for this data category");
    });

    it("should allow emergency access and log it", async function () {
      await contract.connect(provider1).emergencyAccess(patient1.address, 4, "Patient unconscious in ED");
      const log = await contract.getAccessLog(patient1.address, 0);
      expect(log.purposeNote).to.include("EMERGENCY");
    });
  });

  describe("Analytics", function () {
    it("should track counters correctly", async function () {
      await contract.connect(patient1).registerPatient("Alice Smith");
      await contract.registerProvider(provider1.address, "Sydney Hospital", "MED-12345");
      await contract.connect(patient1).grantConsent(provider1.address, 0, 30);
      await contract.connect(provider1).accessPatientData(patient1.address, 0, "Check-up");

      expect(await contract.totalPatients()).to.equal(1);
      expect(await contract.totalProviders()).to.equal(1);
      expect(await contract.totalConsentsGranted()).to.equal(1);
      expect(await contract.totalAccessEvents()).to.equal(1);
    });
  });
});
